"""
Simplified Trading Bot package for Binance Futures Testnet.
"""
